#!/bin/bash
# on OEL, /etc/issue states "Enterprise Linux Enterprise Linux Server"
SUPPORTED_OS='CentOS|Red Hat Enterprise Linux Server|Enterprise Linux Enterprise Linux Server|Fedora|SUSE|Debian GNU/Linux|Ubuntu|Oracle Linux Server'
PROD_NAME="Zend Server"

if ! egrep -q "$SUPPORTED_OS" /etc/issue ; then
cat <<EOF

Unable to install: Your distribution is not suitable for installation using
Zend's DEB/RPM repositories. You can install Zend Server Community Edition on
most Linux distributions using the generic tarball installer. For more 
information, see http://www.zend.com/en/community/zend-server-ce

EOF
    exit 1
fi

if [ $# -lt 1 ]; then
cat <<EOF

Usage: $0 <php_version> [ce]
Where php_version is either 5.2 or 5.3. Pass ce as a second argument if you wish to install the Community edition.

EOF
    exit 1
fi
if [ "$2" = 'ce' ];then
    META_PACK_NAME="zend-server-ce-php-$1"
else
    META_PACK_NAME="zend-server-php-$1"
    CHECK_FOR_META_PACK_NAME="zend-server-ce-php-$1"
fi

MYUID=`id -u 2> /dev/null`
if [ ! -z "$MYUID" ]; then
    if [ $MYUID != 0 ]; then
        echo "You need root privileges to run this script.";
        exit 1
    fi
else
    echo "Could not detect UID";
    exit 1
fi

if [ -n "$CHECK_FOR_META_PACK_NAME" ]; then
	COMMAND=""
	# first, lets figure if we're apt-get or yum
	if which rpm > /dev/null; then
		COMMAND="rpm -q $CHECK_FOR_META_PACK_NAME | grep -q ^$CHECK_FOR_META_PACK_NAME"
	elif which dpkg > /dev/null; then
		COMMAND="dpkg -l $CHECK_FOR_META_PACK_NAME | grep -q ^ii"
	fi

	if [ -n "$COMMAND" ]; then
		eval $COMMAND
		if [ $? -eq 0 ]; then
			echo "To upgrade, go to Zend Server's Administration Interface and enter a serial number."
			exit 1;
		fi
	fi
fi

cat <<EOF

Running this script will perform the following:
* Configure your package manager to use $PROD_NAME repository 
* Install $PROD_NAME on your system using your package manager

Hit ENTER to install $PROD_NAME, or Ctrl+C to abort now.
EOF
read 
# first, lets figure if we're apt-get or yum
if  `which yum &>/dev/null` ;then
    REPO_FILE=`dirname $0`/zend.rpm.repo
    TARGET_REPO_FILE=/etc/yum.repos.d/zend.repo
    TOOL=yum
    SYNC_COMM="touch $TARGET_REPO_FILE"
elif `which zypper &>/dev/null` ;then
	if `grep -q "SUSE Linux Enterprise Server 10" /etc/SuSE-release`; then
		# SLES 10, no repos.d directory exists
		# add repo manually with zypper service-add
		if [ "`uname -m`" == "x86_64" ]; then 
			ARCH=x86_64; 
		elif [ "`uname -m`" == "i686" ]; then 
			ARCH=i586; 
		fi
		TOOL=zypper
		SLES10_MODE=yes;
	else
		REPO_FILE=`dirname $0`/zend.rpm.suse.repo
		mkdir -p /etc/zypp/repos.d
		TARGET_REPO_FILE=/etc/zypp/repos.d/zend.repo
		TOOL=zypper
		SYNC_COMM="touch $TARGET_REPO_FILE"

		# Change arch in the repo file 
                if [ "`uname -m`" == "x86_64" ]; then
                        ARCH=x86_64;
                elif [ "`uname -m`" == "i686" ]; then
                        ARCH=i586;
                fi
		sed -i "s/\$basearch/$ARCH/g" ${REPO_FILE}
	fi
elif `which apt-get &>/dev/null`;then
    REPO_FILE=`dirname $0`/zend.deb.repo
    TARGET_REPO_FILE=/etc/apt/sources.list.d/zend.list
    TOOL=apt-get
    SYNC_COMM="$TOOL update"
    wget http://repos.zend.com/zend.key -O- | apt-key add -
fi
if [ "x${SLES10_MODE}" == "xyes" ]; then
	zypper service-add http://repos.zend.com/zend-server/sles/ZendServer-${ARCH}/ "ZendServer-${ARCH}"	
	zypper service-add http://repos.zend.com/zend-server/sles/ZendServer-noarch/ "ZendServer-noarch"	
else
	cp $REPO_FILE $TARGET_REPO_FILE
	$SYNC_COMM
fi
$TOOL install $META_PACK_NAME
if [ $? -eq 0 ]; then
    echo "$PROD_NAME was successfully installed."
else
    echo "$PROD_NAME Installation was not completed. See $TOOL output above for detailed error information."
fi

