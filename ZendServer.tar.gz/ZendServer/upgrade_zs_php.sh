#!/bin/bash
# on OEL, /etc/issue states "Enterprise Linux Enterprise Linux Server"
SUPPORTED_OS='CentOS|Red Hat Enterprise Linux Server|Enterprise Linux Enterprise Linux Server|Fedora|SUSE|Oracle Linux Server'
PROD_NAME="Zend Server"

if ! egrep -q "$SUPPORTED_OS" /etc/issue ; then
cat <<EOF

This script is meant for upgrading the $PROD_NAME PHP version for RPM based systems.
If you're using Debian or Ubuntu, simply run:
# apt-get install zend-server-php-5.3
Or, to install $PROD_NAME CE:
# apt-get install zend-server-ce-php-5.3 
as super user.

EOF
    exit 1
fi

if [ $# -lt 1 ]; then
cat <<EOF

Usage: $0 <php_version> [ce]
Where php_version is either 5.2 or 5.3. Pass ce as a second argument if you wish to install the Community edition.

EOF
    exit 1
else
    PHP_VER=$1
fi
if [ -n "$2" ];then
    FLAVOR=$2
fi
if rpm -q mod-php-5.2-apache2-zend-server --quiet;then
    CUR_PHP_VER="5.2"
elif rpm -q mod-php-5.3-apache2-zend-server --quiet;then
    CUR_PHP_VER="5.3"
else
    echo "You do not seem to have ZS installed. To install for the first time, please run: install_zs.sh"
    exit 1
fi

# Check if the php-$CUR_PHP_VER-extra-extensions CE|PE is installed
if rpm -q php-$CUR_PHP_VER-extra-extensions-zend-server-ce --quiet || rpm -q php-$CUR_PHP_VER-extra-extensions-zend-server --quiet ;then
    EXTRA_EXT_PACK_INSTALLED=1
fi
EXTRA_PHP_PACKS="loader-zend-server java-bridge-zend-server source-zend-server pdo-informix-zend-server pdo-ibm-zend-server ibmdb2-zend-server"
EXTRA_PACKS="zend-server-framework-dojo zend-server-framework-extras control-panel-zend-server" 
if [ "$FLAVOR" == 'ce' ];then
    META_PACK_NAME="zend-server-ce-php-$PHP_VER"
    EXTRA_EXTS_PACK_NAME="php-$PHP_VER-extra-extensions-zend-server-ce"
else
    META_PACK_NAME="zend-server-php-$PHP_VER"
    EXTRA_EXTS_PACK_NAME="php-$PHP_VER-extra-extensions-zend-server"
fi
for PACK in $EXTRA_PHP_PACKS;do 
    if rpm -q php-$CUR_PHP_VER-$PACK --quiet;then
        EXTRA2INSTALL="$EXTRA2INSTALL php-$PHP_VER-$PACK"
    fi
done
if [ -n "$EXTRA_EXT_PACK_INSTALLED" ];then
    EXTRA2INSTALL="$EXTRA2INSTALL $EXTRA_EXTS_PACK_NAME"
fi
for PACK in $EXTRA_PACKS;do 
    if rpm -q $PACK --quiet;then
        EXTRA2INSTALL="$EXTRA2INSTALL $PACK"
    fi
done
MYUID=`id -u 2> /dev/null`
if [ ! -z "$MYUID" ]; then
    if [ $MYUID != 0 ]; then
        echo "You need root privileges to run this script.";
        exit 1
    fi
else
    echo "Could not detect UID";
    exit 1
fi
# get the currently installed package
CUR_ZS_META=`rpm -qa --qf "[%{NAME}]" "zend-server-*php-5.*"`
# if we got nothing, lets just display $PROD_NAME in our question..
if [ -z "$CUR_ZS_META" ];then
    CUR_ZS_META=$PROD_NAME
fi
cat <<EOF

Running this script will preform the following:
* Configure your package manager to use $PROD_NAME repository 
* Remove the previous $PROD_NAME installation if it exists
* Install $PROD_NAME PHP $PHP_VER on your system using your package manager
* Restore old configuration files

Would you like to switch $CUR_ZS_META to PHP $PHP_VER ($META_PACK_NAME)? [N/Y]
EOF
read ANS
if [ "$ANS" != 'Y' -a "$ANS" != 'y' ];then
    echo "Aborting."
    exit 1
fi
if  `which yum &>/dev/null` ;then
	REPO_FILE=`dirname $0`/zend.rpm.repo
	TARGET_REPO_FILE=/etc/yum.repos.d/zend.repo
	TOOL="yum "
	SYNC_COMM="touch $TARGET_REPO_FILE"
elif `which zypper &>/dev/null` ;then
	TOOL=zypper

        # Change arch in the repo file 
        if [ "`uname -m`" == "x86_64" ]; then
                ARCH=x86_64;
        elif [ "`uname -m`" == "i686" ]; then
                ARCH=i586;
        fi

        if `grep -q "SUSE Linux Enterprise Server 10" /etc/SuSE-release`; then
                # SLES 10, no repos.d directory exists
                # add repo manually with zypper service-add
                SLES10_MODE=yes;
	else
		REPO_FILE=`dirname $0`/zend.rpm.suse.repo
		mkdir -p /etc/zypp/repos.d
		TARGET_REPO_FILE=/etc/zypp/repos.d/zend.repo
		SYNC_COMM="touch $TARGET_REPO_FILE"
		sed -i "s/\$basearch/$ARCH/g" ${REPO_FILE}
	fi
else
    echo "Could not find yum in PATH!"
    exit 1
fi

if [ "x${SLES10_MODE}" == "xyes" ]; then
	echo "Not adding repositories automatically, you can add them manually with these commands:
        # zypper service-add http://repos.zend.com/zend-server/sles/ZendServer-${ARCH}/ 'ZendServer-${ARCH}'
        # zypper service-add http://repos.zend.com/zend-server/sles/ZendServer-noarch/ 'ZendServer-noarch'"
	# zypper in SLES10 doesn't support patterns in the remove function (only in search).
	$TOOL remove `rpm -qa --qf "%{NAME}\n" "*zend*"`
	export RC=$?
else
        cp $REPO_FILE $TARGET_REPO_FILE
        $SYNC_COMM
	$TOOL remove "zend-server*-php-5.*" && $TOOL remove "deployment-daemon-zend-server" && $TOOL remove "*zend*"
	export RC=$?
fi

if [ $RC -ne 0 ];then
    echo "Attention! Removal of the ZS meta package failed, please try: $TOOL remove "zend-server*-php-5.*" --noscripts and then re-run $0"
    exit 1
fi
rm /usr/local/zend/etc/rc.d/*
$TOOL install $META_PACK_NAME $EXTRA2INSTALL
if [ $? -eq 0 ]; then
    echo "$PROD_NAME was successfully installed."
    echo "Restoring *.rpmsave files..."
    for conffile in `find /usr/local/zend/ -name "*.rpmsave"`;do echo "Restoring $conffile" ;mv $conffile `echo $conffile|sed 's@.rpmsave@@'`;done
else
    echo "$PROD_NAME Installation was not completed. See $TOOL output above for detailed error information."
fi

if [ -f /etc/zce.rc ];then
	. /etc/zce.rc
	if [ -x $ZCE_PREFIX/bin/setup_jb.sh ];then
		export JAVA_PATH=`grep zend_wd.process.java_daemon= /usr/local/zend/etc/watchdog-jb.ini|awk -F " " '{print $1}'|sed 's@zend_wd.process.java_daemon=\(.*\)\s*.*@\1@'`
		$ZCE_PREFIX/bin/setup_jb.sh
	fi
	$ZCE_PREFIX/bin/zendctl.sh restart
fi
